import React from "react";
import Navbar from "./Navbar";
import '../css/Admin.css';

function DoctorAfterLogin()
{
    return(
        <div id="DoctorAfterLogin">
        <Navbar/>
        </div>
    )
}
export default DoctorAfterLogin